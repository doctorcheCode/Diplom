package ru.academy.department.service;

import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.academy.department.domain.*;
import ru.academy.department.repo.TestRepository;
import ru.academy.department.repo.TestResultRepository;

import java.util.List;

@Service
@RequiredArgsConstructor
public class TestService {

    private final TestRepository tests;
    private final TestResultRepository results;

    public Test get(Long id) {
        return tests.findById(id).orElseThrow();
    }

    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Transactional
    public Test save(Test test, Course course) {
        test.setCourse(course);
        return tests.save(test);
    }

    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Transactional
    public void delete(Long id) {
        tests.deleteById(id);
    }

    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Transactional
    public void addQuestion(Long testId, Question q) {
        Test test = get(testId);
        q.setTest(test);
        test.getQuestions().add(q);
        tests.save(test);
    }

    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Transactional
    public void deleteQuestion(Long questionId) {
        Test test = tests.findAll().stream()
                .filter(t -> t.getQuestions().stream().anyMatch(q -> q.getId().equals(questionId)))
                .findFirst().orElseThrow();
        test.getQuestions().removeIf(q -> q.getId().equals(questionId));
        tests.save(test);
    }

    /** Проверка ответов: один правильный ответ на вопрос, попыток не ограничено. */
    @PreAuthorize("hasRole('STUDENT')")
    @Transactional
    public TestResult submit(Long testId, User student, java.util.Map<Long, Integer> answers) {
        Test test = get(testId);
        int total = test.getQuestions().size();
        int correct = 0;
        for (Question q : test.getQuestions()) {
            Integer a = answers.get(q.getId());
            if (a != null && a == q.getCorrectIndex()) {
                correct++;
            }
        }
        int percent = total == 0 ? 0 : correct * 100 / total;
        int grade = percent >= 90 ? 5 : percent >= 75 ? 4 : percent >= 50 ? 3 : 2;

        TestResult r = new TestResult();
        r.setStudent(student);
        r.setTest(test);
        r.setCorrect(correct);
        r.setTotal(total);
        r.setPercent(percent);
        r.setGrade(grade);
        return results.save(r);
    }

    public List<TestResult> resultsOf(Long studentId) {
        return results.findAllByStudentIdOrderByTakenAtDesc(studentId);
    }

    public List<TestResult> resultsOfTest(Long testId) {
        return results.findAllByTestIdOrderByGradeDescTakenAtDesc(testId);
    }

    public List<TestResultRepository.StudentAvgView> statistics() {
        return results.findStatistics();
    }
}
