package ru.academy.department.service;

import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.academy.department.domain.*;
import ru.academy.department.repo.*;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CourseService {

    private final CourseRepository courses;
    private final EnrollmentRepository enrollments;
    private final NotificationService notifications;

    public List<Course> findAll() {
        return courses.findAllByOrderByIdDesc();
    }

    public List<Course> findByTeacher(User teacher) {
        return courses.findAllByTeacherIdOrderByIdDesc(teacher.getId());
    }

    public Course get(Long id) {
        return courses.findById(id).orElseThrow();
    }

    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Transactional
    public Course save(Course course, User teacher) {
        course.setTeacher(teacher);
        return courses.save(course);
    }

    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Transactional
    public void delete(Long id) {
        courses.deleteById(id);
    }

    @PreAuthorize("hasRole('STUDENT')")
    @Transactional
    public void enroll(User student, Long courseId) {
        Course course = get(courseId);
        if (enrollments.existsByStudentIdAndCourseId(student.getId(), courseId)) {
            throw new IllegalStateException("Вы уже записаны на этот курс");
        }
        Enrollment e = new Enrollment();
        e.setStudent(student);
        e.setCourse(course);
        enrollments.save(e);
        notifications.send(student.getEmail(),
                "Запись на курс: " + course.getTitle(),
                "Здравствуйте, " + student.getUsername() + "!\n\n" +
                        "Вы успешно записаны на курс \"" + course.getTitle() + "\" " +
                        "(" + course.getHours() + " ч.).\n\nОбразовательный портал кафедры.");
    }

    public boolean isEnrolled(Long studentId, Long courseId) {
        return enrollments.existsByStudentIdAndCourseId(studentId, courseId);
    }

    public boolean canEdit(User user, Course course) {
        return user.getRole() == Role.ADMIN ||
                (user.getRole() == Role.TEACHER && course.getTeacher() != null
                        && course.getTeacher().getId().equals(user.getId()));
    }
}
