package ru.academy.department.controller;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import ru.academy.department.service.UserService;

@Controller
@RequiredArgsConstructor
public class AuthController {

    private final UserService userService;

    @Data
    public static class RegisterForm {
        @NotBlank(message = "Логин обязателен") private String username;
        @NotBlank @Email(message = "Некорректный e-mail") private String email;
        @NotBlank(message = "Пароль обязателен") private String password;
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/register")
    public String register(Model model) {
        model.addAttribute("form", new RegisterForm());
        return "register";
    }

    @PostMapping("/register")
    public String register(@Validated @ModelAttribute("form") RegisterForm form,
                           BindingResult br, RedirectAttributes ra) {
        if (br.hasErrors()) {
            return "register";
        }
        try {
            userService.registerStudent(form.getUsername(), form.getEmail(), form.getPassword());
            ra.addFlashAttribute("ok", "Регистрация успешна. Войдите под своим логином.");
            return "redirect:/login";
        } catch (IllegalArgumentException e) {
            ra.addFlashAttribute("error", e.getMessage());
            return "redirect:/register";
        }
    }
}
