package ru.academy.department.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import ru.academy.department.domain.Material;
import ru.academy.department.service.MaterialService;

import java.nio.charset.StandardCharsets;

@Controller
@RequestMapping("/materials")
@RequiredArgsConstructor
public class MaterialController {

    private final MaterialService materials;

    @GetMapping("/{id}")
    public ResponseEntity<byte[]> file(@PathVariable Long id,
                                       @RequestParam(defaultValue = "false") boolean download) {
        Material m = materials.get(id);
        ContentDisposition cd = download
                ? ContentDisposition.attachment().filename(m.getFileName(), StandardCharsets.UTF_8).build()
                : ContentDisposition.inline().filename(m.getFileName(), StandardCharsets.UTF_8).build();
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(m.getContentType()))
                .header(HttpHeaders.CONTENT_DISPOSITION, cd.toString())
                .body(m.getContent());
    }
}
