package ru.academy.department.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.academy.department.domain.Enrollment;

import java.util.List;
import java.util.Optional;

public interface EnrollmentRepository extends JpaRepository<Enrollment, Long> {
    boolean existsByStudentIdAndCourseId(Long studentId, Long courseId);
    Optional<Enrollment> findByStudentIdAndCourseId(Long studentId, Long courseId);
    void deleteAllByStudentId(Long studentId);
    List<Enrollment> findAllByCourseIdOrderByStudentUsernameAsc(Long courseId);

}
