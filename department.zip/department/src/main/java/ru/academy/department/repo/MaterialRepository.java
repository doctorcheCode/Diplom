package ru.academy.department.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.academy.department.domain.Material;

public interface MaterialRepository extends JpaRepository<Material, Long> {
}
