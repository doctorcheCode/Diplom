package ru.academy.department.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import ru.academy.department.domain.Settings;

@Slf4j
@Service
@RequiredArgsConstructor
public class NotificationService {

    private final JavaMailSender mailSender;
    private final SettingsService settingsService;

    @Value("${app.mail.enabled:false}")
    private boolean mailEnabled;

    @Value("${app.from:noreply@example.com}")
    private String from;

    public void send(String to, String subject, String text) {
        Settings s = settingsService.get();
        if (!s.isMailNotifications()) {
            log.info("Уведомления отключены в настройках. (для {}): {}", to, subject);
            return;
        }
        if (!mailEnabled) {
            log.info("MAIL (режим отладки) -> {} : {}", to, subject);
            return;
        }
        try {
            SimpleMailMessage msg = new SimpleMailMessage();
            msg.setFrom(from);
            msg.setTo(to);
            msg.setSubject(subject);
            msg.setText(text);
            mailSender.send(msg);
        } catch (Exception e) {
            log.error("Не удалось отправить письмо на {}: {}", to, e.getMessage());
        }
    }
}
