package ru.academy.department.config;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import ru.academy.department.domain.Role;
import ru.academy.department.domain.User;
import ru.academy.department.repo.UserRepository;

@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final UserRepository users;
    private final PasswordEncoder encoder;

    @Override
    @Transactional
    public void run(String... args) {
        createUser("Зав.кафедрой", "admin@department.local", "admin", Role.ADMIN);
        createUser("Препод", "teacher@department.local", "prepod", Role.TEACHER);
    }

    private void createUser(String username, String email, String password, Role role) {
        if (!users.existsByUsername(username)) {
            User u = new User();
            u.setUsername(username);
            u.setEmail(email);
            u.setPassword(encoder.encode(password));
            u.setRole(role);
            users.save(u);
        }
    }
}
