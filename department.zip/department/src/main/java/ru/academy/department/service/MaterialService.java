package ru.academy.department.service;

import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import ru.academy.department.domain.Course;
import ru.academy.department.domain.Material;
import ru.academy.department.repo.MaterialRepository;

import java.io.IOException;
import java.util.Objects;

@Service
@RequiredArgsConstructor
public class MaterialService {

    private final MaterialRepository materials;
    private final CourseService courseService;

    public Material get(Long id) {
        return materials.findById(id).orElseThrow();
    }

    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Transactional
    public void upload(Long courseId, String title, MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("Файл не выбран");
        }
        try {
            Material m = new Material();
            m.setCourse(courseService.get(courseId));
            m.setTitle(title);
            m.setFileName(Objects.requireNonNullElse(file.getOriginalFilename(), "file"));
            m.setContentType(file.getContentType() != null ? file.getContentType() : "application/octet-stream");
            m.setContent(file.getBytes());
            materials.save(m);
        } catch (IOException e) {
            throw new IllegalStateException("Не удалось прочитать файл", e);
        }
    }

    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Transactional
    public void delete(Long id) {
        materials.deleteById(id);
    }
}

