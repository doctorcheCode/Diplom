package ru.academy.department.service;

import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.academy.department.domain.Announcement;
import ru.academy.department.domain.Course;
import ru.academy.department.repo.AnnouncementRepository;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AnnouncementService {

    private final AnnouncementRepository announcements;
    private final CourseService courseService;

    public List<Announcement> findByCourse(Long courseId) {
        return announcements.findAllByCourseIdOrderByCreatedAtDesc(courseId);
    }

    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Transactional
    public void create(Course course, ru.academy.department.domain.User author,
                       String title, String text) {
        Announcement a = new Announcement();
        a.setCourse(course);
        a.setAuthor(author);
        a.setTitle(title);
        a.setText(text);
        announcements.save(a);
    }

    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Transactional
    public void delete(Long id) {
        announcements.deleteById(id);
    }
}
