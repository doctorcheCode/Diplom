package ru.academy.department.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import ru.academy.department.domain.TestResult;

import java.util.List;

public interface TestResultRepository extends JpaRepository<TestResult, Long> {

    List<TestResult> findAllByStudentIdOrderByTakenAtDesc(Long studentId);

    List<TestResult> findAllByTestIdOrderByGradeDescTakenAtDesc(Long testId);

    /** Статистика: средний балл каждого студента, сортировка от большего к меньшему */
    @Query("""
        select r.student.username as username,
               avg(r.grade)       as avgGrade,
               count(r)           as attempts
        from TestResult r
        group by r.student.username
        order by avg(r.grade) desc, r.student.username asc
        """)
    List<StudentAvgView> findStatistics();

    interface StudentAvgView {
        String getUsername();
        Double getAvgGrade();
        Long getAttempts();
    }

    void deleteAllByStudentId(Long studentId);
    void deleteAllByTestId(Long testId);

}
