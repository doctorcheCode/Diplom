package ru.academy.department.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.academy.department.domain.Test;

public interface TestRepository extends JpaRepository<Test, Long> {
}
