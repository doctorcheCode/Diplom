package ru.academy.department.controller;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import ru.academy.department.domain.Test;
import ru.academy.department.domain.TestResult;
import ru.academy.department.service.TestService;
import ru.academy.department.service.UserService;

import java.util.LinkedHashMap;
import java.util.Map;

@Controller
@RequiredArgsConstructor
public class TestController {

    private final TestService testService;
    private final UserService userService;

    @GetMapping("/tests/{id}")
    public String take(@PathVariable Long id, Model model) {
        Test test = testService.get(id);
        model.addAttribute("test", test);
        model.addAttribute("course", test.getCourse());
        return "test";
    }

    @PostMapping("/tests/{id}/submit")
    public String submit(@PathVariable Long id, HttpServletRequest request, Model model) {
        Map<Long, Integer> answers = new LinkedHashMap<>();
        request.getParameterMap().forEach((name, values) -> {
            if (name.startsWith("q_")) {
                answers.put(Long.parseLong(name.substring(2)), Integer.parseInt(values[0]));
            }
        });
        TestResult result = testService.submit(id, userService.currentUser(), answers);
        model.addAttribute("result", result);
        model.addAttribute("test", result.getTest());
        model.addAttribute("course", result.getTest().getCourse());
        return "test-result";
    }

    @GetMapping("/my-results")
    public String myResults(Model model) {
        model.addAttribute("results", testService.resultsOf(userService.currentUser().getId()));
        return "my-results";
    }

    @GetMapping("/statistics")
    public String statistics(Model model) {
        model.addAttribute("stats", testService.statistics());
        return "statistics";
    }
}
