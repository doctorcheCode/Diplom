package ru.academy.department;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.mail.javamail.JavaMailSender;

@SpringBootApplication
public class DepartmentApplication {
	static void main(String[] args) {
		SpringApplication.run(DepartmentApplication.class, args);
	}

	@Bean
    CommandLineRunner mailDebug(JavaMailSender sender) {
		return args -> {
			if (sender instanceof org.springframework.mail.javamail.JavaMailSenderImpl impl) {
				System.out.println(">>> HOST=" + impl.getHost()
						+ " PORT=" + impl.getPort()
						+ " USER=" + impl.getUsername()
						+ " PASS_LEN=" + (impl.getPassword() == null ? 0 : impl.getPassword().length()));
			}
		};
	}

}
