package ru.academy.department.domain;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "questions")
@Getter @Setter @NoArgsConstructor
public class Question {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "test_id")
    private Test test;

    @Column(nullable = false, length = 1000)
    private String text;

    @Column(nullable = false) private String option1;
    @Column(nullable = false) private String option2;
    @Column(nullable = false) private String option3;
    @Column(nullable = false) private String option4;

    /** индекс правильного варианта: 1..4 */
    @Column(nullable = false)
    private int correctIndex;
}
