package ru.academy.department.domain;

public enum Role { STUDENT, TEACHER, ADMIN }
