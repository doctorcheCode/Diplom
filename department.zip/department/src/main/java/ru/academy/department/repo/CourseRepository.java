package ru.academy.department.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.academy.department.domain.Course;

import java.util.List;

public interface CourseRepository extends JpaRepository<Course, Long> {
    List<Course> findAllByOrderByIdDesc();
    List<Course> findAllByTeacherIdOrderByIdDesc(Long teacherId);
}
