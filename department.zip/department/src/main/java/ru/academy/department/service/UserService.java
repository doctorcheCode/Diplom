package ru.academy.department.service;

import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.academy.department.domain.*;
import ru.academy.department.repo.CourseRepository;
import ru.academy.department.repo.EnrollmentRepository;
import ru.academy.department.repo.TestResultRepository;
import ru.academy.department.repo.UserRepository;

import java.util.List;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository users;
    private final PasswordEncoder encoder;
    private final EnrollmentRepository enrollments;
    private final TestResultRepository testResults;
    private final CourseRepository courses;


    public User currentUser() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return users.findByUsername(auth.getName()).orElseThrow();
    }

    @Transactional
    public User registerStudent(String username, String email, String rawPassword) {
        if (users.existsByUsername(username)) {
            throw new IllegalArgumentException("Логин уже занят");
        }
        if (users.existsByEmailIgnoreCase(email)) {
            throw new IllegalArgumentException("E-mail уже используется");
        }
        User user = new User();
        user.setUsername(username);
        user.setEmail(email);
        user.setPassword(encoder.encode(rawPassword));
        user.setRole(Role.STUDENT);
        return users.save(user);
    }

    @Transactional
    public User create(String username, String email, String rawPassword, Role role) {
        if (users.existsByUsername(username)) {
            throw new IllegalArgumentException("Логин уже занят");
        }
        User user = new User();
        user.setUsername(username);
        user.setEmail(email);
        user.setPassword(encoder.encode(rawPassword));
        user.setRole(role);
        return users.save(user);
    }

    @Transactional
    public void changeRole(Long id, Role role) {
        users.findById(id).ifPresent(u -> u.setRole(role));
    }

    @Transactional
    public void toggleEnabled(Long id) {
        users.findById(id).ifPresent(u -> u.setEnabled(!u.isEnabled()));
    }

    @Transactional
    public void delete(Long id) {
        // 1. результаты тестов самого пользователя
        testResults.deleteAllByStudentId(id);
        // 2. его записи на курсы
        enrollments.deleteAllByStudentId(id);

        // 3. если пользователь — преподаватель: чистим его курсы
        for (Course c : courses.findAllByTeacherIdOrderByIdDesc(id)) {
            for (Test t : c.getTests()) {
                testResults.deleteAllByTestId(t.getId()); // результаты других студентов по его тестам
            }
            courses.delete(c); // каскадно удалит материалы, записи и тесты курса
        }

        users.deleteById(id);
    }

    public List<User> findAll() {
        return users.findAll();
    }
}
