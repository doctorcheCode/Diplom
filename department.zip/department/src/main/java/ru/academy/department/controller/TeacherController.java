package ru.academy.department.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import ru.academy.department.domain.*;
import ru.academy.department.service.*;

@Controller
@RequestMapping("/teacher")
@PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
@RequiredArgsConstructor
public class TeacherController {

    private final CourseService courseService;
    private final MaterialService materialService;
    private final TestService testService;
    private final UserService userService;

    // ---------- Курсы ----------

    @GetMapping("/courses")
    public String courses(Model model) {
        User me = userService.currentUser();
        model.addAttribute("courses", me.getRole() == Role.ADMIN
                ? courseService.findAll() : courseService.findByTeacher(me));
        return "teacher/courses";
    }

    @PostMapping("/courses")
    public String createCourse(@RequestParam String title,
                               @RequestParam(required = false) String description,
                               @RequestParam int hours,
                               RedirectAttributes ra) {
        Course c = new Course();
        c.setTitle(title);
        c.setDescription(description);
        c.setHours(hours);
        courseService.save(c, userService.currentUser());
        ra.addFlashAttribute("ok", "Курс создан");
        return "redirect:/teacher/courses";
    }

    @GetMapping("/courses/{id}/edit")
    public String editCourse(@PathVariable Long id, Model model) {
        Course c = courseService.get(id);
        requireOwner(c);
        model.addAttribute("course", c);
        return "teacher/course-edit";
    }

    @PostMapping("/courses/{id}/edit")
    public String saveCourse(@PathVariable Long id, @RequestParam String title,
                             @RequestParam(required = false) String description,
                             @RequestParam int hours, RedirectAttributes ra) {
        Course c = courseService.get(id);
        requireOwner(c);
        c.setTitle(title);
        c.setDescription(description);
        c.setHours(hours);
        courseService.save(c, c.getTeacher());
        ra.addFlashAttribute("ok", "Курс сохранён");
        return "redirect:/teacher/courses";
    }

    @PostMapping("/courses/{id}/delete")
    public String deleteCourse(@PathVariable Long id, RedirectAttributes ra) {
        requireOwner(courseService.get(id));
        courseService.delete(id);
        ra.addFlashAttribute("ok", "Курс удалён");
        return "redirect:/teacher/courses";
    }

    // ---------- Материалы ----------

    @GetMapping("/courses/{id}/materials")
    public String materials(@PathVariable Long id, Model model) {
        Course c = courseService.get(id);
        requireOwner(c);
        model.addAttribute("course", c);
        return "teacher/materials";
    }

    @PostMapping("/courses/{id}/materials")
    public String upload(@PathVariable Long id, @RequestParam String title,
                         @RequestParam MultipartFile file, RedirectAttributes ra) {
        requireOwner(courseService.get(id));
        try {
            materialService.upload(id, title, file);
            ra.addFlashAttribute("ok", "Материал загружен");
        } catch (Exception e) {
            ra.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/teacher/courses/" + id + "/materials";
    }

    @PostMapping("/materials/{materialId}/delete")
    public String deleteMaterial(@PathVariable Long materialId,
                                 @RequestParam Long courseId, RedirectAttributes ra) {
        materialService.delete(materialId);
        ra.addFlashAttribute("ok", "Материал удалён");
        return "redirect:/teacher/courses/" + courseId + "/materials";
    }

    // ---------- Тесты и вопросы ----------

    @GetMapping("/courses/{id}/tests")
    public String tests(@PathVariable Long id, Model model) {
        Course c = courseService.get(id);
        requireOwner(c);
        model.addAttribute("course", c);
        return "teacher/tests";
    }

    @PostMapping("/courses/{id}/tests")
    public String createTest(@PathVariable Long id, @RequestParam String title, RedirectAttributes ra) {
        requireOwner(courseService.get(id));
        Test t = new Test();
        t.setTitle(title);
        Test saved = testService.save(t, courseService.get(id));
        return "redirect:/teacher/tests/" + saved.getId();
    }

    @GetMapping("/tests/{id}")
    public String testEdit(@PathVariable Long id, Model model) {
        Test t = testService.get(id);
        requireOwner(t.getCourse());
        model.addAttribute("test", t);
        return "teacher/test-edit";
    }

    @PostMapping("/tests/{id}/questions")
    public String addQuestion(@PathVariable Long id,
                              @RequestParam String text,
                              @RequestParam String option1, @RequestParam String option2,
                              @RequestParam String option3, @RequestParam String option4,
                              @RequestParam int correctIndex, RedirectAttributes ra) {
        Test t = testService.get(id);
        requireOwner(t.getCourse());
        Question q = new Question();
        q.setText(text);
        q.setOption1(option1);
        q.setOption2(option2);
        q.setOption3(option3);
        q.setOption4(option4);
        q.setCorrectIndex(correctIndex);
        testService.addQuestion(id, q);
        ra.addFlashAttribute("ok", "Вопрос добавлен");
        return "redirect:/teacher/tests/" + id;
    }

    @PostMapping("/tests/{id}/questions/{qid}/delete")
    public String deleteQuestion(@PathVariable Long id, @PathVariable Long qid) {
        testService.deleteQuestion(qid);
        return "redirect:/teacher/tests/" + id;
    }

    @PostMapping("/tests/{id}/delete")
    public String deleteTest(@PathVariable Long id, RedirectAttributes ra) {
        Test t = testService.get(id);
        requireOwner(t.getCourse());
        testService.delete(id);
        ra.addFlashAttribute("ok", "Тест удалён");
        return "redirect:/teacher/courses/" + t.getCourse().getId() + "/tests";
    }

    // ---------- Результаты по своим курсам ----------

    @GetMapping("/courses/{id}/results")
    public String results(@PathVariable Long id, Model model) {
        Course c = courseService.get(id);
        requireOwner(c);
        model.addAttribute("course", c);
        var byTest = new java.util.LinkedHashMap<Test, java.util.List<TestResult>>();
        c.getTests().forEach(t -> byTest.put(t, testService.resultsOfTest(t.getId())));
        model.addAttribute("byTest", byTest);
        return "teacher/results";
    }

    private void requireOwner(Course c) {
        User me = userService.currentUser();
        if (me.getRole() != Role.ADMIN && !courseService.canEdit(me, c)) {
            throw new org.springframework.security.access.AccessDeniedException("Это не ваш курс");
        }
    }
}
