package ru.academy.department.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.academy.department.domain.Settings;
import ru.academy.department.repo.SettingsRepository;

@Service
@RequiredArgsConstructor
public class SettingsService {

    private final SettingsRepository settings;

    @Transactional
    public Settings get() {
        return settings.findById(1L).orElseGet(() -> settings.save(new Settings()));
    }

    @Transactional
    public void save(Settings s) {
        s.setId(1L);
        settings.save(s);
    }
}
