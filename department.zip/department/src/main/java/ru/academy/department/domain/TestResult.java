package ru.academy.department.domain;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "test_results")
@Getter @Setter @NoArgsConstructor
public class TestResult {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "student_id")
    private User student;

    @ManyToOne(optional = false)
    @JoinColumn(name = "test_id")
    private Test test;

    @Column(nullable = false) private int correct;
    @Column(nullable = false) private int total;
    @Column(nullable = false) private int percent;
    /** оценка по 5-балльной шкале */
    @Column(nullable = false) private int grade;

    @Column(nullable = false)
    private LocalDateTime takenAt = LocalDateTime.now();
}
