package ru.academy.department.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.academy.department.domain.Announcement;

import java.util.List;

public interface AnnouncementRepository extends JpaRepository<Announcement, Long> {
    List<Announcement> findAllByCourseIdOrderByCreatedAtDesc(Long courseId);
}
