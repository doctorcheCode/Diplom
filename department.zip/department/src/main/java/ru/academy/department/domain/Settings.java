package ru.academy.department.domain;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "settings")
@Getter @Setter @NoArgsConstructor
public class Settings {

    @Id
    private Long id = 1L;

    private boolean mailNotifications = true;
}
