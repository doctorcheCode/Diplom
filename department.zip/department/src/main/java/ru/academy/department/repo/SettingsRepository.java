package ru.academy.department.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.academy.department.domain.Settings;

public interface SettingsRepository extends JpaRepository<Settings, Long> {
}
