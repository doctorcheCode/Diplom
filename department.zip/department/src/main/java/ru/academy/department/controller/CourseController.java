package ru.academy.department.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import ru.academy.department.domain.Course;
import ru.academy.department.repo.EnrollmentRepository;
import ru.academy.department.service.AnnouncementService;
import ru.academy.department.service.CourseService;
import ru.academy.department.service.UserService;

import java.security.Principal;

@Controller
@RequiredArgsConstructor
public class CourseController {

    private final CourseService courses;
    private final UserService userService;
    private final AnnouncementService announcementService;
    private final EnrollmentRepository enrollments;


    @GetMapping("/courses")
    public String list(Model model, Principal principal) {
        model.addAttribute("courses", courses.findAll());
        var current = userService.currentUser();
        model.addAttribute("enrolledIds",
                courses.findAll().stream()
                        .filter(c -> courses.isEnrolled(current.getId(), c.getId()))
                        .map(Course::getId).toList());
        return "courses";
    }

    @GetMapping("/courses/{id}")
    public String detail(@PathVariable Long id, Model model) {
        Course course = courses.get(id);
        model.addAttribute("course", course);
        model.addAttribute("enrolled", courses.isEnrolled(userService.currentUser().getId(), id));
        model.addAttribute("announcements", announcementService.findByCourse(id));
        model.addAttribute("enrollments",
                enrollments.findAllByCourseIdOrderByStudentUsernameAsc(id));

        return "course";
    }

    @PreAuthorize("hasRole('STUDENT')")
    @PostMapping("/courses/{id}/enroll")
    public String enroll(@PathVariable Long id, RedirectAttributes ra) {
        try {
            courses.enroll(userService.currentUser(), id);
            ra.addFlashAttribute("ok", "Вы записаны на курс. Уведомление отправлено на ваш e-mail.");
        } catch (IllegalStateException e) {
            ra.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/courses/" + id;
    }

    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @PostMapping("/courses/{id}/announcements")
    public String addAnnouncement(@PathVariable Long id,
                                  @RequestParam String title,
                                  @RequestParam String text,
                                  RedirectAttributes ra) {
        Course course = courses.get(id);
        if (!courses.canEdit(userService.currentUser(), course)) {
            throw new org.springframework.security.access.AccessDeniedException("Это не ваш курс");
        }
        announcementService.create(course, userService.currentUser(), title, text);
        ra.addFlashAttribute("ok", "Объявление опубликовано");
        return "redirect:/courses/" + id;
    }

    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @PostMapping("/courses/{id}/announcements/{announcementId}/delete")
    public String deleteAnnouncement(@PathVariable Long id, @PathVariable Long announcementId,
                                     RedirectAttributes ra) {
        Course course = courses.get(id);
        if (!courses.canEdit(userService.currentUser(), course)) {
            throw new org.springframework.security.access.AccessDeniedException("Это не ваш курс");
        }
        announcementService.delete(announcementId);
        ra.addFlashAttribute("ok", "Объявление удалено");
        return "redirect:/courses/" + id;
    }

}
