package ru.academy.department.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import ru.academy.department.domain.Role;
import ru.academy.department.domain.Settings;
import ru.academy.department.service.SettingsService;
import ru.academy.department.service.UserService;

@Controller
@RequestMapping("/admin")
@PreAuthorize("hasRole('ADMIN')")
@RequiredArgsConstructor
public class AdminController {

    private final UserService userService;
    private final SettingsService settingsService;

    @GetMapping("/users")
    public String users(Model model) {
        model.addAttribute("users", userService.findAll());
        model.addAttribute("currentUsername", userService.currentUser().getUsername());
        return "admin/users";
    }

    @PostMapping("/users")
    public String create(@RequestParam String username, @RequestParam(required = false) String email,
                         @RequestParam String password, @RequestParam Role role,
                         RedirectAttributes ra) {
        try {
            userService.create(username, email, password, role);
            ra.addFlashAttribute("ok", "Пользователь создан");
        } catch (IllegalArgumentException e) {
            ra.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/admin/users";
    }

    @PostMapping("/users/{id}/role")
    public String changeRole(@PathVariable Long id, @RequestParam Role role, RedirectAttributes ra) {
        if (userService.currentUser().getId().equals(id)) {
            ra.addFlashAttribute("error", "Нельзя менять роль собственной учётке");
            return "redirect:/admin/users";
        }
        userService.changeRole(id, role);
        ra.addFlashAttribute("ok", "Роль изменена");
        return "redirect:/admin/users";
    }


    @PostMapping("/users/{id}/toggle")
    public String toggle(@PathVariable Long id) {
        userService.toggleEnabled(id);
        return "redirect:/admin/users";
    }

    @PostMapping("/users/{id}/delete")
    public String delete(@PathVariable Long id, RedirectAttributes ra) {
        if (userService.currentUser().getId().equals(id)) {
            ra.addFlashAttribute("error", "Нельзя удалить самого себя");
            return "redirect:/admin/users";
        }
        try {
            userService.delete(id);
            ra.addFlashAttribute("ok", "Пользователь удалён");
        } catch (Exception e) {
            ra.addFlashAttribute("error", "Не удалось удалить пользователя");
        }
        return "redirect:/admin/users";
    }

    @GetMapping("/settings")
    public String settings(Model model) {
        model.addAttribute("settings", settingsService.get());
        return "admin/settings";
    }

    @PostMapping("/settings")
    public String saveSettings(@RequestParam boolean mailNotifications, RedirectAttributes ra) {
        Settings s = settingsService.get();
        s.setMailNotifications(mailNotifications);
        settingsService.save(s);
        ra.addFlashAttribute("ok", "Настройки сохранены");
        return "redirect:/admin/settings";
    }
}
