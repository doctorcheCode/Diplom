package ru.academy.department;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DepartmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
